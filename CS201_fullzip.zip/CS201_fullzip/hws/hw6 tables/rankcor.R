rankcor <- function(x, y){
  n <- length(x)
  stopifnot(length(y) == n)
  
  x.ranks <- rank(x)
  y.ranks <- rank(y)
  
  mean.x <- mean(x.ranks)
  mean.y <- mean(y.ranks)
  
  covariance.term <- cov(x.ranks - mean.x, y - mean.y)
  
  sd.x <- sd(x.ranks)
  sd.y <- sd(y.ranks)
  
  rank.cor <- covariance.term / (sd.x*sd.y)
  
  return(rank.cor)
}